create function format_employee_id() returns trigger
    language plpgsql
as
$$
DECLARE
 seqId INT;
 yearPrefix INT;
BEGIN
 SELECT nextval('employee_id_seq') INTO seqId;
 SELECT TO_CHAR(NOW(), 'YY')::INT INTO yearPrefix;
 NEW.id := yearPrefix * 10000 + seqId;
 RETURN NEW;
END;
$$;

alter function format_employee_id() owner to postgres;

